// Confetti effect for birthday celebration
const canvas = document.getElementById('confetti');
const ctx = canvas.getContext('2d');
let W = window.innerWidth;
let H = window.innerHeight;
canvas.width = W;
canvas.height = H;

const confettiCount = 130,
    confettiArr = [];

function randomRange(a, b) {
    return Math.random() * (b - a) + a;
}
class Confetti {
    constructor() {
        this.x = randomRange(0, W);
        this.y = randomRange(-H, 0);
        this.r = randomRange(5, 11);
        this.sx = randomRange(-1, 1);
        this.sy = randomRange(2, 5);
        this.color = `hsl(${randomRange(320,370)}, 92%, 65%)`;
        this.angle = randomRange(0, 2 * Math.PI);
        this.spin = randomRange(-0.08, 0.08);
    }
    update() {
        this.x += this.sx;
        this.y += this.sy;
        this.angle += this.spin;
        if (this.y > H) {
            this.y = randomRange(-30, 0);
            this.x = randomRange(0, W);
        }
        if (this.x > W) this.x = 0;
        if (this.x < 0) this.x = W;
    }
    draw() {
        ctx.save();
        ctx.translate(this.x, this.y);
        ctx.rotate(this.angle);
        ctx.fillStyle = this.color;
        ctx.fillRect(-this.r / 2, -this.r / 2, this.r, this.r);
        ctx.restore();
    }
}

function initConfetti() {
    for (let i = 0; i < confettiCount; i++) confettiArr.push(new Confetti());
}

function animate() {
    ctx.clearRect(0, 0, W, H);
    confettiArr.forEach(c => {
        c.update();
        c.draw();
    });
    requestAnimationFrame(animate);
}
window.addEventListener('resize', () => {
    W = window.innerWidth;
    H = window.innerHeight;
    canvas.width = W;
    canvas.height = H;
});
initConfetti();
animate();